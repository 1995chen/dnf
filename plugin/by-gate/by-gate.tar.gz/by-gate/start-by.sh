#!/bin/bash

set -e

CURR_PATH=`pwd`

echo "Current path ${CURR_PATH}"

HOME_PATH="/home/neople/game"
ROOT_PATH="/root"
HOME_TAR_PATH="${CURR_PATH}/bygw_home.tar.gz"
ROOT_TAR_PATH="${CURR_PATH}/bygw_root.tar.gz"


# Install
echo "Install by-gate"
tar -zxvf ${HOME_TAR_PATH} -C ${HOME_PATH}
tar -zxvf ${ROOT_TAR_PATH} -C ${ROOT_PATH}

echo "Start by-gate"
pushd ${ROOT_PATH}
./Restart
popd